package com.example.mp_wortspiel;

public class UserDetails {
    String user, password, emailid;
    public String getUser() {
        return this.user;
    }
    public String getPassword() {
        return this.password;
    }
    public String getEmailid() {
        return this.emailid;
    }
    public void setUser(String user) {
        this.user = user;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

}
